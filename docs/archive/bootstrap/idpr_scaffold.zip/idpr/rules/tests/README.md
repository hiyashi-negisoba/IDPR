# Golden tests
rule마다 최소 3케이스: 성립 / 불성립 / 경계(게이트 관련 rule은 배제증거 케이스 필수).
형식: 케이스별 facts(jsonl) + expected derivation(json). `pytest tests/test_rules.py`가 전체 실행.
golden test 없는 rule은 머지 불가 (PROJECT_INIT.md §6).
