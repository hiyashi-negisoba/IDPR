# IDPR — In Dubio Pro Reo

Logic-verified long-form legal document generation.
**결론은 논리가 계산하고, 문장은 모델이 쓴다.**

## Quickstart
```bash
uv sync
cp .env.example .env   # API 키 입력
uv run scripts/run_pipeline.py --config configs/pipeline.yaml --item data/processed/sample.json
```

온보딩은 `PROJECT_INIT.md`부터. 스테이지 간 계약은 `docs/contracts/`가 유일한 기준.
