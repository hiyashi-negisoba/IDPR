# CLI 엔트리포인트 (구현 순서 = W1 순서)
- tag_inventory.py   : 변시 원문 -> 설문 분해 + 쟁점 태깅 (LLM 초벌, human_verified 승격은 별도)
- build_rules.py     : 주석서 텍스트 -> rule 초안(draft) 생성 (rulegen)
- run_pipeline.py    : 설문 1건 또는 배치에 대해 S1->S4 실행
- run_eval.py        : ours + 베이스라인 + ablation 일괄 실행, experiments/runs.jsonl 기록
